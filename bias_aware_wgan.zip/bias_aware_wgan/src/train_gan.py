import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import os

data = pd.read_csv("data/processed/train.csv")
fraud = data[data["Class"] == 1].drop("Class", axis=1).values

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

latent_dim = 32
epochs = 250
batch_size = 64
lr = 0.00005

class Generator(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(latent_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, fraud.shape[1])
        )

    def forward(self, z):
        return self.model(z)

class Critic(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(fraud.shape[1], 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

    def forward(self, x):
        return self.model(x)

G = Generator().to(device)
D = Critic().to(device)

opt_G = optim.RMSprop(G.parameters(), lr=lr)
opt_D = optim.RMSprop(D.parameters(), lr=lr)

fraud_tensor = torch.tensor(fraud, dtype=torch.float32).to(device)

for epoch in range(epochs):
    for i in range(0, len(fraud_tensor), batch_size):
        real = fraud_tensor[i:i+batch_size]

        z = torch.randn(real.size(0), latent_dim).to(device)
        fake = G(z)

        loss_D = -(torch.mean(D(real)) - torch.mean(D(fake)))

        opt_D.zero_grad()
        loss_D.backward()
        opt_D.step()

        for p in D.parameters():
            p.data.clamp_(-0.01, 0.01)

        if i % 5 == 0:
            z = torch.randn(real.size(0), latent_dim).to(device)
            fake = G(z)
            loss_G = -torch.mean(D(fake))

            opt_G.zero_grad()
            loss_G.backward()
            opt_G.step()

    print(f"Epoch {epoch+1}/{epochs} | D Loss: {loss_D.item()} | G Loss: {loss_G.item()}")

os.makedirs("models/gan", exist_ok=True)
# torch.save(G.state_dict(), "models/gan/wgan_generator.pth")
# torch.save(G.state_dict(), "models/gan/wgan_generator_v2.pth")
torch.save(G.state_dict(), "models/gan/wgan_generator_v3.pth")

print("done")