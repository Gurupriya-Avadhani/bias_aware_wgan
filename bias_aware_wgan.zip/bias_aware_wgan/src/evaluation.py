import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split
import os

df_before = pd.read_csv("data/processed/train.csv")
df_after = pd.read_csv("data/processed/augmented_v3.csv")

X_before = df_before.drop("Class", axis=1)
y_before = df_before["Class"]

X_after = df_after.drop("Class", axis=1)
y_after = df_after["Class"]

X_train_b, X_test_b, y_train_b, y_test_b = train_test_split(
    X_before, y_before, test_size=0.2, stratify=y_before, random_state=42
)

X_train_a, X_test_a, y_train_a, y_test_a = train_test_split(
    X_after, y_after, test_size=0.2, stratify=y_after, random_state=42
)

model_before = RandomForestClassifier(n_estimators=100, random_state=42)
model_before.fit(X_train_b, y_train_b)

model_after = RandomForestClassifier(n_estimators=100, random_state=42)
model_after.fit(X_train_a, y_train_a)

y_pred_before = model_before.predict(X_test_b)
y_pred_after = model_after.predict(X_test_a)

before = (
    precision_score(y_test_b, y_pred_before),
    recall_score(y_test_b, y_pred_before),
    f1_score(y_test_b, y_pred_before)
)

after = (
    precision_score(y_test_a, y_pred_after),
    recall_score(y_test_a, y_pred_after),
    f1_score(y_test_a, y_pred_after)
)

metrics = ["Precision", "Recall", "F1"]

x = range(len(metrics))

plt.figure()
plt.plot(x, before, marker='o', label="Before GAN")
plt.plot(x, after, marker='o', label="After GAN")

plt.xticks(x, metrics)
plt.legend()
plt.title("Performance Comparison")

os.makedirs("results/graphs", exist_ok=True)
plt.savefig("results/graphs/comparison.png")

print("Before GAN:", before)
print("After GAN:", after)
