import torch
import pandas as pd

latent_dim = 32

class Generator(torch.nn.Module):
    def __init__(self, output_dim):
        super().__init__()
        self.model = torch.nn.Sequential(
            torch.nn.Linear(latent_dim, 64),
            torch.nn.ReLU(),
            torch.nn.Linear(64, 128),
            torch.nn.ReLU(),
            torch.nn.Linear(128, output_dim)
        )

    def forward(self, z):
        return self.model(z)

data = pd.read_csv("data/processed/train.csv")
input_dim = data.drop("Class", axis=1).shape[1]

G = Generator(input_dim)
# G.load_state_dict(torch.load("models/gan/wgan_generator.pth", map_location="cpu"))
# G.load_state_dict(torch.load("models/gan/wgan_generator_v2.pth", map_location="cpu"))
G.load_state_dict(torch.load("models/gan/wgan_generator_v3.pth", map_location="cpu"))
G.eval()

z = torch.randn(5000, latent_dim)
synthetic = G(z).detach().numpy()

synthetic_df = pd.DataFrame(synthetic, columns=data.drop("Class", axis=1).columns)
synthetic_df["Class"] = 1

augmented = pd.concat([data, synthetic_df], ignore_index=True)
# augmented.to_csv("data/processed/augmented.csv", index=False)
# augmented.to_csv("data/processed/augmented_v2.csv", index=False)
augmented.to_csv("data/processed/augmented_v3.csv", index=False)

print("done")