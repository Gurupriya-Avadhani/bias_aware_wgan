import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import os

df = pd.read_csv("data/raw/creditcard.csv")

X = df.drop("Class", axis=1)
y = df["Class"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

processed_df = pd.DataFrame(X_scaled, columns=X.columns)
processed_df["Class"] = y.values

os.makedirs("data/processed", exist_ok=True)
processed_df.to_csv("data/processed/processed_data.csv", index=False)

train_df, test_df = train_test_split(processed_df, test_size=0.2, random_state=42, stratify=processed_df["Class"])

train_df.to_csv("data/processed/train.csv", index=False)
test_df.to_csv("data/processed/test.csv", index=False)

print("✅ Data preprocessing done")