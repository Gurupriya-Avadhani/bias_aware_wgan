import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import train_test_split
import seaborn as sns
import matplotlib.pyplot as plt
import os

def train_and_evaluate(data_path, label):
    df = pd.read_csv(data_path)

    X = df.drop("Class", axis=1)
    y = df["Class"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)

    cm = confusion_matrix(y_test, y_pred)

    os.makedirs("results/confusion_matrix", exist_ok=True)

    plt.figure()
    sns.heatmap(cm, annot=True, fmt='d')
    plt.title(label)
    plt.savefig(f"results/confusion_matrix/{label}.png")
    plt.close()

    return precision, recall, f1

before = train_and_evaluate("data/processed/train.csv", "before_gan")
after = train_and_evaluate("data/processed/augmented_v3.csv", "after_gan_v3")

metrics = ["Precision", "Recall", "F1"]

before_vals = list(before)
after_vals = list(after)

x = range(len(metrics))

plt.figure()
plt.plot(x, before_vals, marker='o', label="Before GAN")
plt.plot(x, after_vals, marker='o', label="After GAN")

plt.xticks(x, metrics)
plt.legend()
plt.title("Performance Comparison")

os.makedirs("results/graphs", exist_ok=True)
plt.savefig("results/graphs/comparison.png")

print("Before GAN:", before)
print("After GAN:", after)

