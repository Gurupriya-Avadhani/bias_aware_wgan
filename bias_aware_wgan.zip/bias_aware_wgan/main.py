from src.preprocessing import load_data, split_data, scale_data
from src.model import train_model, predict
from src.utils import evaluate

X, y = load_data("data/raw/creditcard.csv")

X_train, X_test, y_train, y_test = split_data(X, y)

X_train, X_test, scaler = scale_data(X_train, X_test)

model = train_model(X_train, y_train)

y_pred = predict(model, X_test)

report, cm, recall, f1 = evaluate(y_test, y_pred)

print(cm)
print(report)
print(recall, f1)