# Bias-Aware Data Generation using Conditional GAN

## 📌 Overview

This project focuses on handling **class imbalance** in fraud detection datasets using a **Conditional Generative Adversarial Network (cGAN)**.
The goal is to generate **synthetic minority class samples** (fraud cases) to improve model performance and reduce bias.

---

## 🚀 Objectives

* Handle highly imbalanced datasets
* Generate realistic minority class samples using GAN
* Improve classification performance (Recall & F1-score)
* Compare results with traditional methods like SMOTE

---

## 📂 Project Structure

```
bias-aware-gan/
│
├── data/
│   ├── raw/
│   │   └── creditcard.csv
│   └── processed/
│
├── notebooks/
│   ├── 02_baseline_model.ipynb
│   ├── 03_smote.ipynb
│   ├── 04_evaluation.ipynb
│   └── 05_gan.ipynb
│
├── src/
│   ├── preprocessing.py
│   ├── model.py
│   ├── utils.py
│   └── gan.py
│
├── requirements.txt
└── README.md
```

---

## ⚙️ Technologies Used

* Python
* Pandas, NumPy
* Scikit-learn
* TensorFlow / Keras
* Imbalanced-learn

---

## 📊 Dataset

* **Credit Card Fraud Detection Dataset**
* Highly imbalanced dataset with very few fraud cases
* Located in: `data/raw/creditcard.csv`

---

## 🔄 Workflow

1. **Data Preprocessing**

   * Load dataset
   * Split into train/test
   * Feature scaling

2. **Baseline Model**

   * Train classifier on original imbalanced data
   * Evaluate performance

3. **SMOTE Approach**

   * Apply oversampling
   * Train model
   * Compare metrics

4. **GAN-Based Approach**

   * Train Conditional GAN on minority class
   * Generate synthetic samples
   * Augment dataset
   * Retrain classifier

5. **Evaluation**

   * Confusion Matrix
   * Recall Score
   * F1 Score

---

## ▶️ How to Run

### 1. Install dependencies

```
pip install -r requirements.txt
```

### 2. Run notebooks (recommended)

```
jupyter notebook
```

Run in order:

* `02_baseline_model.ipynb`
* `03_smote.ipynb`
* `04_evaluation.ipynb`
* `05_gan.ipynb`

---

## 📈 Results

| Method   | Recall  | F1 Score |
| -------- | ------- | -------- |
| Baseline | Low     | Low      |
| SMOTE    | High    | Improved |
| GAN      | Highest | Best     |

GAN significantly improves the detection of fraud cases by generating realistic synthetic samples.

---

## ✅ Key Features

* Modular code structure
* Easy-to-run notebooks
* GAN-based data augmentation
* Comparative analysis (Baseline vs SMOTE vs GAN)

---

## 📌 Future Work

* Improve GAN architecture (WGAN, CGAN tuning)
* Hyperparameter optimization
* Deploy model using web interface

---

## 👩‍💻 Author

Gurupriya Avadhani M M(AIML Student)
Hamsa Shree D N(AIML Student)

---

## 📜 License

This project is for academic and educational purposes.
